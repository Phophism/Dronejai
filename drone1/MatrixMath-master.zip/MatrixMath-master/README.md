# MatrixMath
A GitHub repo for the MatrixMath Arduino library - http://playground.arduino.cc/Code/MatrixMath

There is a nice Arduine library on the Arduino Playground for Matrix Mathematical operations, but it wasn't in the form of a library, and it required extra work to be installed and used, so we brought this into a good state and added it up on GitHub for anyone who is interested in using it

Enjoy ;)


### License

The original author didn't specify a License, but I'm going out on a limb and guessing that he implied GPL2. I would also be happy if someone offered me a beer for my work, so you could also consider it BeerWare.

But as I said, I don't know the original author's intentions, so think of it what you will, just don't sue me or anything
