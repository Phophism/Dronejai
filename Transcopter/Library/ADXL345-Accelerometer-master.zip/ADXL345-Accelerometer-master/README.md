ADXL345 Accelerometer
=======================

ADXL345 Accelerometer Arduino Library, work in progress!

The library can be found on the Arduino folder, if you want to use it just rename it to ADXL345 and add it to the directory libraries on your Arduino sketchbook folder.
To use the Processing examples, just add them to your Processing sketchbook folder and load the corresponding [Arduino] code to your Arduino.

**Examples:**

* pitch_roll: calculates pitch and roll using the gravity measurement, or rather the "deviation from free fall" measurement. You can also view this information using the corresponding processing example.


