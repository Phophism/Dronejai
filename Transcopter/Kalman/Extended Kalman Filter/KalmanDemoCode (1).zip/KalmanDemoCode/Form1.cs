﻿///////////////////////////////////////////////////////////////////////////////
//
//  Form1.cs
//
//  By Philip R. Braica (HoshiKata@aol.com, VeryMadSci@gmail.com)
//
//  Fully open source, public domain license, have fun.
//  http://creativecommons.org/licenses/publicdomain/
///////////////////////////////////////////////////////////////////////////////

// Using.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

// Namespace
namespace KalmanDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            NumericUpDown[] nds = { 
                numericUpDown1, numericUpDown2, numericUpDown3, 
                numericUpDown4, numericUpDown5, numericUpDown6,
                numericUpDown7, numericUpDown8, numericUpDown9};

            for (int i = 0; i < nds.Length; i++)
            {
                nds[i].ValueChanged += new EventHandler(numericUpdown_ValueChanged);
            }
        }

        /// <summary>
        /// Retrigger last button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numericUpdown_ValueChanged(object sender, EventArgs e)
        {
            button1_Click(sender, e);
        } 

        
        /// <summary>
        /// Test 1.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void button1_Click(object sender, EventArgs e)
        {
            GPS_Path gp = new GPS_Path((int)numericUpDown9.Value);


            /*
            Kalman1D k = new Kalman1D();
            k.Reset(
                (double)numericUpDown1.Value,
                (double)numericUpDown2.Value,
                (double)numericUpDown3.Value,
                (double)numericUpDown4.Value, 0);
            */

       
            // Chart stuff.
            chart1.Series.Clear();
            chart2.Series.Clear();
            
            Series idealPosition = new Series("Ideal");
            Series measuredPosition = new Series("Measured");
            Series kalmanPosition = new Series("Kalman");
            Series rateSmoothedPosition = new Series("Rate smoothed");

            Series measuredError = new Series("Measurement error");
            Series kalmanError = new Series("Kalman error");
            Series rateError = new Series("Rate smoothed error");
            
            idealPosition.ChartType = SeriesChartType.Line;
            measuredPosition.ChartType = SeriesChartType.Point;
            measuredPosition.MarkerStyle = MarkerStyle.Cross;
            measuredPosition.MarkerSize = 2;
            kalmanPosition.ChartType = SeriesChartType.Line;
            rateSmoothedPosition.ChartType = SeriesChartType.Point;
            rateSmoothedPosition.MarkerStyle = MarkerStyle.Cross;
            rateSmoothedPosition.MarkerSize = 2;

            measuredError.ChartType = SeriesChartType.Point;
            measuredError.MarkerStyle = MarkerStyle.Cross;
            measuredError.MarkerSize = 2;

            kalmanError.ChartType = SeriesChartType.Line;
            rateError.ChartType = SeriesChartType.Line;

            idealPosition.Color = Color.Red;
            measuredPosition.Color = Color.Blue;
            kalmanPosition.Color = Color.Green;
            rateSmoothedPosition.Color = Color.Orange;

            measuredError.Color = Color.Blue;
            kalmanError.Color = Color.Green;
            rateError.Color = Color.Orange;

            Series test1 = new Series("t1");
            Series test2 = new Series("t2");
            Series test3 = new Series("t3");
            Series test4 = new Series("t4");
            test1.ChartType = SeriesChartType.Line;
            test2.ChartType = SeriesChartType.Line;
            test3.ChartType = SeriesChartType.Line;
            test4.ChartType = SeriesChartType.Line;
            test1.Color = Color.Red;
            test2.Color = Color.Blue;
            test3.Color = Color.Green;
            test4.Color = Color.Orange;


            double rx = gp.Meas_X[0];
            double ry = gp.Meas_Y[0];

            // This approach is an accelerometer based velocity smoothing (k2d_v* filters)
            // that then produces a very trustworthy velocity to combine with the not 
            // very trustworthy GPS position measurement.
            //
            // The idea was, doppler (GPS velocity) is far less likely to "jump" as 
            // satellites are added / removed from the GPS constellation, so it behaves 
            // nicer and mixes better with accelerometer data. The alternative is a 3rd order
            // Kalman, which would work, but has a few tuning problems:
            //    * When GPS constellation changes, a "jump" in position is seen usually 2-15 meters,
            //      where the solution then settles, but does so without a major change in velocity.
            //    * Not all constellation changes are reported by all GPS receivers, 
            //      most GPS report a snapshot of satellite use but not if the 
            //      satellite wasn't in use inbetween.
            //    * By knowing the Kalman gain in velocity and positional filters, we can
            //      add a "coast" to the position, we'd know when position became untrustworthy. 
            //      Then slow down, calculate a local average delta and then remove 
            //      it from the data. We could also slow down the thing we're driving 
            //      until the solution settles completely. Can't easily do that with 1 big filter.
            Kalman2D k2d_x = new Kalman2D();
            Kalman2D k2d_y = new Kalman2D();
            Kalman2D k2d_vx = new Kalman2D();
            Kalman2D k2d_vy = new Kalman2D();
      
            k2d_x.Reset(
                (double)numericUpDown1.Value,
                (double)numericUpDown8.Value,
                (double)numericUpDown3.Value,
                200, 0);
            k2d_y.Reset(
                (double)numericUpDown1.Value,
                (double)numericUpDown8.Value,
                (double)numericUpDown3.Value,
                200, 0);

            k2d_vx.Reset(
                (double)numericUpDown2.Value,
                (double)numericUpDown7.Value,
                (double)numericUpDown4.Value,
                200, 0);
            k2d_vy.Reset(
                (double)numericUpDown2.Value,
                (double)numericUpDown7.Value,
                (double)numericUpDown4.Value,
                200, 0);
            
            for (int i = 0; i < gp.Ideal_Time.Count; i+=100)
            {
                idealPosition.Points.Add(new DataPoint(gp.Ideal_X[i], gp.Ideal_Y[i]));    
            }

            int measHint = 0;
            int kalHint = 0;
            int rateErrHint = 0;
            double aveMeasErr = 0;
            double aveKalErr = 0;
            double aveRateErr = 0;
            double seperation = gp.AmountInFront;
            double measErrCount = 0;
            double kalmanErrCount = 0;
            double rateErrCount = 0;

            double dt = gp.Meas_Time[1] - gp.Meas_Time[0];
            for (int i = 0; i < gp.Meas_Time.Count; i ++)
            {
                measuredPosition.Points.Add(new DataPoint(gp.Meas_X[i], gp.Meas_Y[i]));
                
                // Precondition using both measurements and both velocities and the fact that 
                // we are always a certain amount in front, and always moving in the direction of 
                // pt1 to pt 2.
                double aveX = gp.Meas_X[i];
                double aveY = gp.Meas_Y[i];
                double aveVX = gp.Meas_VX[i];
                double aveVY = gp.Meas_VY[i];                
                double aveAX = gp.Meas_AX[i];                
                double aveAY = gp.Meas_AY[i];

                aveAX = aveAX < -2 ? -2 : aveAX > 2 ? 2 : aveAX;
                aveAY = aveAY < -2 ? -2 : aveAY > 2 ? 2 : aveAY;

                // Simple rate smoothing, uses part of the new position measurement with the 
                // rate to move the existing one forward, basically the "predict"
                // pieve of a Kalman filter with some smoothing.
                rx = (0.9 * (rx + dt * gp.Meas_VX[i])) + 0.1 * gp.Meas_X[i];
                ry = (0.9 * (ry + dt * gp.Meas_VY[i])) + 0.1 * gp.Meas_Y[i];
                rateSmoothedPosition.Points.Add(new DataPoint(rx, ry));

                // Kalman.
                double vx = k2d_vx.Update(aveVX, aveAX, dt);
                double vy = k2d_vy.Update(aveVY, aveAY, dt);
                double kx = k2d_x.Update(aveX, vx, dt);
                double ky = k2d_y.Update(aveY, vy, dt);
                kalmanPosition.Points.Add(new DataPoint(kx, ky));

                double err = gp.ComputeError(gp.Meas_X[i], gp.Meas_Y[i], ref measHint);
                if (double.IsNaN(err) || double.IsInfinity(err))
                {
                    err = 0;
                }
                else
                {
                    measErrCount++;
                }
                measuredError.Points.Add(new DataPoint(i, err));
                aveMeasErr += err;
                
                err = gp.ComputeError(kx, ky, ref kalHint);
                if (double.IsNaN(err) || double.IsInfinity(err))
                {
                    err = 0;
                }
                else
                {
                    if (i > 50) 
                    {
                        kalmanError.Points.Add(new DataPoint(i, err));

                        // Not in inital wait.
                        if ((i < 1200) || (i > 1800))
                        {
                            // Not during the turn, we are stopped about to start the run
                            // after 1250.
                            aveKalErr += err;
                            kalmanErrCount++;
                            
                        }
                    }
                }
                
                
                err = gp.ComputeError(rx, ry, ref rateErrHint);
                if (double.IsNaN(err) || double.IsInfinity(err))
                {
                    err = 0;
                }
                else
                {
                    rateErrCount++;
                }
                rateError.Points.Add(new DataPoint(i, err));
                aveRateErr += err;

                test1.Points.Add(new DataPoint(i, k2d_vx.Value));
                test2.Points.Add(new DataPoint(i, k2d_vy.Value));

                test3.Points.Add(new DataPoint(i, gp.idealVX[i]));
                test4.Points.Add(new DataPoint(i, gp.idealVY[i]));            
            }

            aveMeasErr /= measErrCount;
            aveRateErr /= rateErrCount;
            aveKalErr /= kalmanErrCount;

            richTextBox1.Text = "Raw err = " + aveMeasErr + "\r\nRate smoothed err = " + aveRateErr + "\r\nKalman err = " + aveKalErr; 
            chart1.ResetAutoValues();
            chart2.ResetAutoValues();

            chart1.Series.Add(idealPosition);
            chart1.Series.Add(measuredPosition);
            chart1.Series.Add(kalmanPosition);
            chart1.Series.Add(rateSmoothedPosition);

            chart2.Series.Add(measuredError);
            chart2.Series.Add(rateError);
            chart2.Series.Add(kalmanError);

            chart3.Series.Clear();
            chart3.ResetAutoValues();
            chart3.Series.Add(kalmanError);
          
            chart4.Series.Clear();
            chart4.ResetAutoValues();
            chart4.Series.Add(test1);
            chart4.Series.Add(test2);
            chart4.Series.Add(test3);
            chart4.Series.Add(test4);
            
        }

        /// <summary>
        /// Compute distance.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="x2"></param>
        /// <param name="y2"></param>
        /// <returns></returns>
        protected double computeDistance(double x, double y, double x2, double y2)
        {
            x -= x2;
            y -= y2;
            x = x * x;
            y = y * y;
            return System.Math.Sqrt(x + y);
        }

        /// <summary>
        /// Append a graph.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="name"></param>
        /// <param name="vals"></param>
        /// <param name="clr"></param>
        protected void graph(Chart c, string name, double[] vals, Color clr)
        {
            Series s = new Series(name);
            s.ChartType = SeriesChartType.Line;

            for (int i = 0; i < vals.Length; i++)
            {
                s.Points.Add(new DataPoint(i, vals[i]));
            }
            s.Color = clr;
            c.Series.Add(s);
        }

       


        /// <summary>
        /// Form a test.
        /// </summary>
        /// <param name="idealNoNoise"></param>
        protected void formTest2D(double[] idealNoNoise, double[] idealNoNoiseVelocity)
        {
            RandomNumbers.Random r = new RandomNumbers.Random();
            // Add in wind, auto-pilot on our rocket always successfully adapts so
            // that the effect by the wind is guassian process noise.
            double[] withProcessNoise = new double[idealNoNoise.Length];
            double[] withProcessNoiseVel = new double[idealNoNoise.Length];
            for (int i = 0; i < idealNoNoise.Length; i++)
            {
                // Add in 1 foot = 1 std. deviation of process noise.
                withProcessNoise[i] = idealNoNoise[i] + r.NextGuass_Double(0, (double)numericUpDown5.Value);
                withProcessNoiseVel[i] = idealNoNoiseVelocity[i] + r.NextGuass_Double(0, (double)numericUpDown6.Value);
            }

            // Add in measurement noise, the GPS on the rocket measures less often
            // than our data but we can just skip things.
            // Assume a very good GPS, accurate to +/- 6 feet even at these speeds.
            // 2 foot = 1 std dev. is about +/- 6 feet
            double[] withAllNoise = new double[idealNoNoise.Length];
            double[] withAllNoiseVel = new double[idealNoNoise.Length];
            for (int i = 0; i < idealNoNoise.Length; i++)
            {
                // Add in 1 foot = 1 std. deviation of process noise.
                withAllNoise[i] = withProcessNoise[i] + r.NextGuass_Double(0, (double)numericUpDown6.Value);
                withAllNoiseVel[i] = withProcessNoiseVel[i] + r.NextGuass_Double(0, 0.2*(double)numericUpDown6.Value);
            }

            Kalman2D k = new Kalman2D();
            k.Reset(
                (double)numericUpDown1.Value,
                (double)numericUpDown2.Value,
                (double)numericUpDown3.Value,
                (double)numericUpDown4.Value, 0);

            // Assume we get to see every other measurement we calculated, and use
            // the others as the points to compare for estimates.
            // Run the filter, note our time unit is 1.
            double[] kalman = new double[idealNoNoise.Length];
            double[] vel = new double[idealNoNoise.Length];
            double[] kGain = new double[idealNoNoise.Length];
            for (int i = 0; i < idealNoNoise.Length; i ++)
            {
                if (i == 0)
                {
                    kalman[0] = 0;
                    vel[0] = k.Velocity;
                    kGain[0] = k.LastGain;
                }
                else
                {
                    kalman[i] = k.Update(withAllNoise[i], withAllNoiseVel[i], 1);
                    vel[i] = k.Velocity;
                    kGain[i] = k.LastGain;
                }

            }

            for (int i = 0; i < kalman.Length; i++)
            {
                kalman[i] = (kalman[i] < 100000000000000) ? kalman[i] : 100000000000000;
                kalman[i] = (kalman[i] > -100000000000000) ? kalman[i] : -100000000000000;
                vel[i] = (vel[i] < 100000000000000) ? vel[i] : 100000000000000;
                vel[i] = (vel[i] > -100000000000000) ? vel[i] : -100000000000000;
            }

            // Compute errors.
            double[] kalmanDelIdeal = new double[idealNoNoise.Length];
            double[] measuredDelIdeal = new double[idealNoNoise.Length];
            for (int i = 0; i < idealNoNoise.Length; i += 2)
            {
                kalmanDelIdeal[i] = kalman[i] - idealNoNoise[i];
                measuredDelIdeal[i] = withAllNoise[i] - idealNoNoise[i];
            }
            
            // Chart stuff.
            chart1.Series.Clear();
            graph(chart1, "ideal", idealNoNoise, Color.Black);
            graph(chart1, "measured", withAllNoise, Color.Blue);
            graph(chart1, "kalman", kalman, Color.Red);
            chart1.ChartAreas[0].RecalculateAxesScale();

            chart2.Series.Clear();
            graph(chart2, "Measurement", measuredDelIdeal, Color.Blue);
            graph(chart2, "Kalman", kalmanDelIdeal, Color.Black);
            chart2.ChartAreas[0].RecalculateAxesScale();

            chart3.Series.Clear();
            graph(chart3, "Velocity", vel, Color.Black);
            chart3.ChartAreas[0].RecalculateAxesScale();

            chart4.Series.Clear();
            graph(chart4, "Gain", kGain, Color.Black);
            chart4.ChartAreas[0].RecalculateAxesScale();
        }

        /// <summary>
        /// Basic matrix unit test.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            Matrix c = new Matrix(1, 2) { Data = new double[] { 1, 2 } };
            Matrix r = new Matrix(2, 1) { Data = new double[] { 2, 3 } };

            r.Multiply(c);
            if (r.Data[0] != (2 + 6)) return;

            r = new Matrix(2, 1) { Data = new double[] { 2, 3 } };

            c.Multiply(r);
            if (c.Data[0] != 2) return;
            if (c.Data[1] != 3) return;
            if (c.Data[2] != 4) return;
            if (c.Data[3] != 6) return;

            c.Transpose();
            if (c.Data[0] != 2) return;
            if (c.Data[1] != 4) return;
            if (c.Data[2] != 3) return;
            if (c.Data[3] != 6) return;

            c.Data[3] = 2;
            Matrix ci = Matrix.Invert(c);
            if (ci.Data[0] != -0.250) return;
            if (ci.Data[1] != 0.375) return;
            if (ci.Data[2] != 0.5) return;
            if (ci.Data[3] != -0.250) return;
 
        }


        



    }
}
